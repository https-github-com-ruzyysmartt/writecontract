# writecontract
Etherscan write contract
From: <Saved by Blink>
Snapshot-Content-Location: https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory/edit/master/README.md
Subject: =?utf-8?Q?Editing=20Commit-remix-debungge-Complite-set-reposentory/README?=
 =?utf-8?Q?.md=20at=20master=20=C2=B7=20ruzyysmartt/Commit-remix-debungge-?=
 =?utf-8?Q?Complite-set-reposentory?=
Date: Sat, 28 Dec 2019 03:00:37 -0000
MIME-Version: 1.0
Content-Type: multipart/related;
	type="text/html";
	boundary="----MultipartBoundary--YZBtZvQLA0WiVqlv6MI63HqfXm8RJLRDN9Z7t9QCFl----"


------MultipartBoundary--YZBtZvQLA0WiVqlv6MI63HqfXm8RJLRDN9Z7t9QCFl----
Content-Type: text/html
Content-ID: <frame-C8E6896F4BFE3B90904ACA43ED9801C5@mhtml.blink>
Content-Transfer-Encoding: binary
Content-Location: https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory/edit/master/README.md

<!DOCTYPE html><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
  <link rel="dns-prefetch" href="https://github.githubassets.com/">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com/">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/frameworks-02a3eaa24db2bd1ed9b64450595fc2cf.css">
  
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/github-102d2679bcc893600ce928d5c6d34297.css">
    
    
    
    


  <meta name="viewport" content="width=device-width">
  
  <title>Editing Commit-remix-debungge-Complite-set-reposentory/README.md at master · ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory</title>
    <meta name="description" content=" Contract ABI  [{&quot;name&quot;: &quot;TokenPurchase&quot;, &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;buyer&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_sold&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;, &quot;indexed&quot;: true}], &quot;anonymous&quot;: false, &quot;type&quot;: &quot;event&quot;}, {&quot;name&quot;: &quot;EthPurchase&quot;, &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;buyer&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_bought&quot;, &quot;indexed&quot;: true}], &quot;anonymous&quot;: false, &quot;type&quot;: &quot;event&quot;}, {&quot;name&quot;: &quot;AddLiquidity&quot;, &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;provider&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_amount&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;token_amount&quot;, &quot;indexed&quot;: true}], &quot;anonymous&quot;: false, &quot;type&quot;: &quot;event&quot;}, {&quot;name&quot;: &quot;RemoveLiquidity&quot;, &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;provider&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_amount&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;token_amount&quot;, &quot;indexed&quot;: true}], &quot;anonymous&quot;: false, &quot;type&quot;: &quot;event&quot;}, {&quot;name&quot;: &quot;Transfer&quot;, &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_from&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_to&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;_value&quot;, &quot;indexed&quot;: false}], &quot;anonymous&quot;: false, &quot;type&quot;: &quot;event&quot;}, {&quot;name&quot;: &quot;Approval&quot;, &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_owner&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_spender&quot;, &quot;indexed&quot;: true}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;_value&quot;, &quot;indexed&quot;: false}], &quot;anonymous&quot;: false, &quot;type&quot;: &quot;event&quot;}, {&quot;name&quot;: &quot;setup&quot;, &quot;outputs&quot;: [], &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;token_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 175875}, {&quot;name&quot;: &quot;addLiquidity&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_liquidity&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_tokens&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: true, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 82616}, {&quot;name&quot;: &quot;removeLiquidity&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;amount&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_eth&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_tokens&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 116814}, {&quot;name&quot;: &quot;__default__&quot;, &quot;outputs&quot;: [], &quot;inputs&quot;: [], &quot;constant&quot;: false, &quot;payable&quot;: true, &quot;type&quot;: &quot;function&quot;}, {&quot;name&quot;: &quot;ethToTokenSwapInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_tokens&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: true, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 12757}, {&quot;name&quot;: &quot;ethToTokenTransferInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_tokens&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: true, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 12965}, {&quot;name&quot;: &quot;ethToTokenSwapOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: true, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 50463}, {&quot;name&quot;: &quot;ethToTokenTransferOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: true, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 50671}, {&quot;name&quot;: &quot;tokenToEthSwapInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_eth&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 47503}, {&quot;name&quot;: &quot;tokenToEthTransferInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_eth&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 47712}, {&quot;name&quot;: &quot;tokenToEthSwapOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_tokens&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 50175}, {&quot;name&quot;: &quot;tokenToEthTransferOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_tokens&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 50384}, {&quot;name&quot;: &quot;tokenToTokenSwapInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_eth_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;token_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 51007}, {&quot;name&quot;: &quot;tokenToTokenTransferInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_eth_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;token_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 51098}, {&quot;name&quot;: &quot;tokenToTokenSwapOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_eth_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;token_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 54928}, {&quot;name&quot;: &quot;tokenToTokenTransferOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_eth_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;token_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 55019}, {&quot;name&quot;: &quot;tokenToExchangeSwapInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_eth_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;exchange_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 49342}, {&quot;name&quot;: &quot;tokenToExchangeTransferInput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;min_eth_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;exchange_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 49532}, {&quot;name&quot;: &quot;tokenToExchangeSwapOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_eth_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;exchange_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 53233}, {&quot;name&quot;: &quot;tokenToExchangeTransferOutput&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_tokens_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;max_eth_sold&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;deadline&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;recipient&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;exchange_addr&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 53423}, {&quot;name&quot;: &quot;getEthToTokenInputPrice&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_sold&quot;}], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 5542}, {&quot;name&quot;: &quot;getEthToTokenOutputPrice&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_bought&quot;}], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 6872}, {&quot;name&quot;: &quot;getTokenToEthInputPrice&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;tokens_sold&quot;}], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 5637}, {&quot;name&quot;: &quot;getTokenToEthOutputPrice&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;eth_bought&quot;}], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 6897}, {&quot;name&quot;: &quot;tokenAddress&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1413}, {&quot;name&quot;: &quot;factoryAddress&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1443}, {&quot;name&quot;: &quot;balanceOf&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_owner&quot;}], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1645}, {&quot;name&quot;: &quot;transfer&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;bool&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_to&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;_value&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 75034}, {&quot;name&quot;: &quot;transferFrom&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;bool&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_from&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_to&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;_value&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 110907}, {&quot;name&quot;: &quot;approve&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;bool&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_spender&quot;}, {&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;_value&quot;}], &quot;constant&quot;: false, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 38769}, {&quot;name&quot;: &quot;allowance&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [{&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_owner&quot;}, {&quot;type&quot;: &quot;address&quot;, &quot;name&quot;: &quot;_spender&quot;}], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1925}, {&quot;name&quot;: &quot;name&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;bytes32&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1623}, {&quot;name&quot;: &quot;symbol&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;bytes32&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1653}, {&quot;name&quot;: &quot;decimals&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1683}, {&quot;name&quot;: &quot;totalSupply&quot;, &quot;outputs&quot;: [{&quot;type&quot;: &quot;uint256&quot;, &quot;name&quot;: &quot;out&quot;}], &quot;inputs&quot;: [], &quot;constant&quot;: true, &quot;payable&quot;: false, &quot;type&quot;: &quot;function&quot;, &quot;gas&quot;: 1713}] - ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory">
    <link rel="search" type="application/opensearchdescription+xml" href="https://github.com/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    <meta name="twitter:image:src" content="https://avatars1.githubusercontent.com/u/52005723?s=400&amp;v=4"><meta name="twitter:site" content="@github"><meta name="twitter:card" content="summary"><meta name="twitter:title" content="ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory"><meta name="twitter:description" content=" Contract ABI  [{&amp;amp;quot;name&amp;amp;quot;: &amp;amp;quot;TokenPurchase&amp;amp;quot;, &amp;amp;quot;inputs&amp;amp;quot;: [{&amp;amp;quot;type&amp;amp;quot;: &amp;amp;quot;address&amp;amp;quot;, &amp;amp;quot;name&amp;amp;quot;: &amp;amp;quo...">
    <meta property="og:image" content="https://avatars1.githubusercontent.com/u/52005723?s=400&amp;v=4"><meta property="og:site_name" content="GitHub"><meta property="og:type" content="object"><meta property="og:title" content="ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory"><meta property="og:url" content="https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory"><meta property="og:description" content=" Contract ABI  [{&amp;quot;name&amp;quot;: &amp;quot;TokenPurchase&amp;quot;, &amp;quot;inputs&amp;quot;: [{&amp;quot;type&amp;quot;: &amp;quot;address&amp;quot;, &amp;quot;name&amp;quot;: &amp;quot;buyer&amp;quot;, &amp;quot;indexed&amp;quot;: true}, {&amp;quot;ty...">

  <link rel="assets" href="https://github.githubassets.com/">
  <link rel="web-socket" href="wss://live.github.com/_sockets/VjI6NDgyMjg3ODk4OjJjNWQ2NDA2NDM0MGE3NGU0MzAxNGVjMzIyYWJiYTk4YWU4OTI2N2Q0NmNkMjAxZDRjMTg5YWE3NjNmYTQ2NzI=--8351b41e075ada0140ae23b69125ffb603144ba4">
  <link rel="sudo-modal" href="https://github.com/sessions/sudo_modal">

    <meta name="request-id" content="D6A9:04C4:3C76000:54343EB:5E06C521" data-pjax-transient="">



  

  <meta name="selected-link" value="repo_source" data-pjax-transient="">

      <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
    <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

    <meta name="octolytics-host" content="collector.githubapp.com"><meta name="octolytics-app-id" content="github"><meta name="octolytics-event-url" content="https://collector.githubapp.com/github-external/browser_event"><meta name="octolytics-dimension-request_id" content="D6A9:04C4:3C76000:54343EB:5E06C521"><meta name="octolytics-dimension-region_edge" content="ap-southeast-1"><meta name="octolytics-dimension-region_render" content="iad"><meta name="octolytics-dimension-ga_id" content="2056313748.1577425146" class="js-octo-ga-id"><meta name="octolytics-dimension-visitor_id" content="3206277170616178935"><meta name="octolytics-actor-id" content="52005723"><meta name="octolytics-actor-login" content="ruzyysmartt"><meta name="octolytics-actor-hash" content="6e1b94d10c89c0c7c95e4577cb9a739bf3d67c5ba1cccb5dada19bb1dbd6fd3c">

<meta name="analytics-location" content="/<user-name>/<repo-name>/blob/edit" data-pjax-transient="true">



    <meta name="google-analytics" content="UA-3769691-2">

  <meta class="js-ga-set" name="userId" content="4e652ee9d64b562e8285130b18a6e57b">

<meta class="js-ga-set" name="dimension1" content="Logged In">

  <meta class="js-ga-set" name="dimension3" content="mobile">


  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="ruzyysmartt">

      <meta name="expected-hostname" content="github.com">

      <meta name="js-proxy-site-detection-payload" content="YTcyYWZkOTBmNTViZmEyMGYwNWMxNjE5M2JhMGIzZjVjMTViZGQxZWUwMDBmYTM3NjEzNWZlZGRjY2JlZTg4MXx7InJlbW90ZV9hZGRyZXNzIjoiMTEzLjIxMC4xODEuNTAiLCJyZXF1ZXN0X2lkIjoiRDZBOTowNEM0OjNDNzYwMDA6NTQzNDNFQjo1RTA2QzUyMSIsInRpbWVzdGFtcCI6MTU3NzUwMjAzNSwiaG9zdCI6ImdpdGh1Yi5jb20ifQ==">

    <meta name="enabled-features" content="MARKETPLACE_FEATURED_BLOG_POSTS,MARKETPLACE_INVOICED_BILLING,MARKETPLACE_SOCIAL_PROOF_CUSTOMERS,MARKETPLACE_TRENDING_SOCIAL_PROOF,MARKETPLACE_RECOMMENDATIONS,MARKETPLACE_PENDING_INSTALLATIONS,NOTIFY_ON_BLOCK,RELATED_ISSUES,GHE_CLOUD_TRIAL">

    <meta name="html-safe-nonce" content="521d4bb620c1b3de18344085522b660e63586f7d">

  <meta http-equiv="x-pjax-version" content="61f8c219e8739359a3bf9c46bc342ad6">
  

      <link href="https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory/commits/master.atom" rel="alternate" title="Recent Commits to Commit-remix-debungge-Complite-set-reposentory:master" type="application/atom+xml">

  <meta name="go-import" content="github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory git https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory.git">

  <meta name="octolytics-dimension-user_id" content="52005723"><meta name="octolytics-dimension-user_login" content="ruzyysmartt"><meta name="octolytics-dimension-repository_id" content="230549143"><meta name="octolytics-dimension-repository_nwo" content="ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory"><meta name="octolytics-dimension-repository_public" content="true"><meta name="octolytics-dimension-repository_is_fork" content="false"><meta name="octolytics-dimension-repository_network_root_id" content="230549143"><meta name="octolytics-dimension-repository_network_root_nwo" content="ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory"><meta name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" content="false">




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" class="js-site-favicon" href="https://github.githubassets.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



  <meta name="webauthn-auth-enabled" content="true">

  <meta name="webauthn-registration-enabled" content="true">

  <link rel="manifest" href="https://github.com/manifest.json" crossorigin="use-credentials">

  </head>

  <body class="logged-in env-production page-responsive page-edit-blob">
    

  <div class="position-relative js-header-wrapper ">
    <a href="https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory/edit/master/README.md#start-of-content" tabindex="1" class="p-3 bg-blue text-white show-on-focus js-skip-to-content">Skip to content</a>
    <span class="Progress progress-pjax-loader position-fixed width-full js-pjax-loader-bar">
      <span class="progress-pjax-loader-bar top-0 left-0" style="width: 0%;"></span>
    </span>

    
    
    


          <header class="Header js-details-container Details flex-wrap flex-lg-nowrap p-responsive" role="banner">

    <div class="Header-item d-none d-lg-flex">
      <a class="Header-link" href="https://github.com/" data-hotkey="g d" aria-label="Homepage" data-ga-click="Header, go to dashboard, icon:logo">
  <svg class="octicon octicon-mark-github v-align-middle" height="32" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path></svg>
</a>

    </div>

    <div class="Header-item d-lg-none">
      <button class="Header-link btn-link js-details-target" type="button" aria-label="Toggle navigation" aria-expanded="false">
        <svg height="24" class="octicon octicon-three-bars" viewBox="0 0 12 16" version="1.1" width="18" aria-hidden="true"><path fill-rule="evenodd" d="M11.41 9H.59C0 9 0 8.59 0 8c0-.59 0-1 .59-1H11.4c.59 0 .59.41.59 1 0 .59 0 1-.59 1h.01zm0-4H.59C0 5 0 4.59 0 4c0-.59 0-1 .59-1H11.4c.59 0 .59.41.59 1 0 .59 0 1-.59 1h.01zM.59 11H11.4c.59 0 .59.41.59 1 0 .59 0 1-.59 1H.59C0 13 0 12.59 0 12c0-.59 0-1 .59-1z"></path></svg>
      </button>
    </div>

    <div class="Header-item Header-item--full flex-column flex-lg-row width-full flex-order-2 flex-lg-order-none mr-0 mr-lg-3 mt-3 mt-lg-0 Details-content--hidden">
        <div class="header-search flex-self-stretch flex-lg-self-auto mr-0 mr-lg-3 mb-3 mb-lg-0 scoped-search site-scoped-search js-site-search position-relative " role="search">
  <div class="position-relative">
    <!-- '"` --><!-- </textarea></xmp> --><form class="js-site-search-form" role="search" aria-label="Site" data-scope-type="Repository" data-scope-id="230549143" data-scoped-search-url="/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory/search" data-unscoped-search-url="/search" action="https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory/search" accept-charset="UTF-8" method="get">
      <label class="form-control input-sm header-search-wrapper p-0  js-chromeless-input-container">
            <a class="header-search-scope no-underline" href="https://github.com/ruzyysmartt/Commit-remix-debungge-Complite-set-reposentory/edit/master/README.md">This repository</a>
        <input type="text" class="form-control input-sm header-search-input  js-site-search-focus js-site-search-field is-clearable" data-hotkey="s,/" name="q" value="" placeholder="Search" data-unscoped-placeholder="Search GitHub" data-scoped-placeholder="Search" autocapitalize="off" aria-label="Search this repository">
          
      </label>
</form>  </div>
</div>
